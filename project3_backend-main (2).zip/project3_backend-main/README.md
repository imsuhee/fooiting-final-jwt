# project3_backend
[팀 프로젝트] 백엔드

### 구현화면
##### 기본화면 
![1  기본화면_1](https://github.com/sonbuwon/project3_backend/assets/84784246/46a6a49a-4fac-424b-895d-a8c38dfacd8f)
##### 목록
![3  인기 TOP3_1](https://github.com/sonbuwon/project3_backend/assets/84784246/99303056-d3f5-46d6-a5b9-05ecf296f2b9)
##### 회원가입
![5  회원가입](https://github.com/sonbuwon/project3_backend/assets/84784246/0fda1d4d-19a0-4b02-91eb-e38f9de7c862)
##### 로그인
![6  로그인](https://github.com/sonbuwon/project3_backend/assets/84784246/05d0687f-2dec-4848-97a3-228afddf91b5)
##### 마이페이지 및 정보수정
![7  마이페이지 및 정보수정](https://github.com/sonbuwon/project3_backend/assets/84784246/8a992cf6-0896-46da-bf68-9aaeabe11cf3)
##### 예약기능
![8  예약기능](https://github.com/sonbuwon/project3_backend/assets/84784246/b77a12b0-b39c-4747-ba9a-d370db0aad37)
##### 중복 예약 방지 및 예약 삭제
![9  중복 예약 방지 및 예약 삭제](https://github.com/sonbuwon/project3_backend/assets/84784246/a6330731-a27e-4f9f-8572-d64e320b9ac4)
##### 권한에 따른 기능
![10  권한에 따른 기능](https://github.com/sonbuwon/project3_backend/assets/84784246/160635fe-3c5e-4c88-b604-657966a801da)
##### 관리자 업체등록
![11  관리자 업체등록](https://github.com/sonbuwon/project3_backend/assets/84784246/c4f46005-c166-4979-af44-474b5e5e8bc8)
