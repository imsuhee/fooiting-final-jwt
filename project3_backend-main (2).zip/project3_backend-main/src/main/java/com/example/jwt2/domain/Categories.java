package com.example.jwt2.domain;

public enum Categories {
    한식, 중식, 일식, 양식, 카페, 피자, 치킨, 분식, 고기, 호텔, 오마카세, 파인다이닝
}
