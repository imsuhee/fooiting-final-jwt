package com.example.jwt2.dto.restaurant;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RestaurantReservationRequestDTO {
    private String restaurantId;
}
