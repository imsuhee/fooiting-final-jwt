package com.example.jwt2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jwt2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
